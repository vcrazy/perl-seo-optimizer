Title: Perl Crawler
Description: This crawler logs all the links present in the url supplied and also the links present in the links that are generated in a log file.
This program basically outputs all the links present in a website

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=686&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
